export const bodyToUser = (body) => {
  const dob = new Date(body.dob);

  return {
    email: body.email,
    name: body.name,
    gender: body.gender,
    dob,
    address: body.address || "",
    detailAddress: body.detailAddress || "",
    phoneNumber: body.phoneNumber,
    preferences: body.preferences,
  };
};

export const responseFromUser = (user) => {
  return {
    userId: user.userId,
    email: user.email,
    name: user.name,
    gender: user.gender,
    dob: user.dob.toISOString().split('T')[0],  // 날짜를 YYYY-MM-DD 형식으로 변환
    address: user.address || "",
    detailAddress: user.detailAddress || "",
    phoneNumber: user.phoneNumber,
    preferences: user.preferences || [],  // 기본적으로 빈 배열로 설정
    createdAt: user.createdAt ? user.createdAt.toISOString() : null,
    updatedAt: user.updatedAt ? user.updatedAt.toISOString() : null,
  };
};

