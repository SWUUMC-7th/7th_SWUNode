//특정 지역에 가게 추가하기
import { StatusCodes } from "http-status-codes";
import { bodyToStore } from "../dtos/store.dto.js";
import { addStore } from "../repositories/store.repository.js";

export const handleAddStore = async (req, res) => {
  try {
    const store = bodyToStore(req.body);
    const result = await addStore(store);
    res.status(StatusCodes.CREATED).json({ result });
  } catch (error) {
    console.error(error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).send('Server error');
  }
};

