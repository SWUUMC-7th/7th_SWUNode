//가게에 리뷰 추가하기
import { StatusCodes } from "http-status-codes";
import { bodyToReview } from "../dtos/review.dto.js";
import { addReview } from "../repositories/review.repository.js";

export const handleAddReview = async (req, res) => {
  try {
    const review = bodyToReview(req.body);
    const result = await addReview(review);
    res.status(StatusCodes.CREATED).json({ result });
  } catch (error) {
    console.error(error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).send('Server error');
  }
};
